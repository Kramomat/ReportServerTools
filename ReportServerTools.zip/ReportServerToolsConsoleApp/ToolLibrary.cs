﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Net.Http;
using ReportServerTools.Properties;
using System.Net;
using System.Data;

namespace ReportServerTools
{
    public class ToolLibrary
    {
        /// <summary>
        /// Reads to be warmed reports from configuration table
        /// Opens http connections to Report Server and executes warming
        /// </summary>
        public async Task ExecuteCacheWarming()
        {
            HttpClientHandler handler = new HttpClientHandler();

            handler.Credentials = new NetworkCredential(Settings.Default.Benutzername, Settings.Default.Passwort);

            HttpClient client = new HttpClient(handler);

            SqlConnection sqlcon = new SqlConnection(Settings.Default.SQLConnectionString);
            SqlConnection sqlconLog = new SqlConnection(Settings.Default.SQLConnectionString);
            // Select Reports to be warmed
            SqlCommand sqlCommand = new SqlCommand("SELECT ItemID FROM CacheWarming WHERE [ActivateCacheWarming] = 1", sqlcon);
            // Insert Log Entry
            SqlCommand sqlCommandLogInsert = new SqlCommand(@"INSERT INTO CacheWarmingLog (ItemId, StartTime, Status)
                                                                OUTPUT INSERTED.CacheWarmingLogID
                                                                VALUES (@ItemId, getdate(), 0)", sqlconLog);
            sqlCommandLogInsert.Parameters.Add("@ItemId", SqlDbType.UniqueIdentifier);
            // Update Log Entry
            SqlCommand sqlCommandLogUpdate = new SqlCommand(@"UPDATE CacheWarmingLog
                                                              SET EndTime = getdate(), Status=@Status, Details=@Details, Duration=datediff(s,StartTime,getdate())
                                                              WHERE CacheWarmingLogID = @CacheWarmingLogID", sqlconLog);
            sqlCommandLogUpdate.Parameters.Add("@Status", SqlDbType.Int);
            sqlCommandLogUpdate.Parameters.Add("@Details", SqlDbType.VarChar, 4000);
            sqlCommandLogUpdate.Parameters["@Details"].IsNullable = true;
            sqlCommandLogUpdate.Parameters.Add("@CacheWarmingLogID", SqlDbType.Int);

            int logid;
            HttpResponseMessage response;
            Guid itemId;
            bool isError;

            sqlcon.Open();
            sqlconLog.Open();
            SqlDataReader sqlReaderReportList = sqlCommand.ExecuteReader();
            while (sqlReaderReportList.Read())
            {
                itemId = sqlReaderReportList.GetGuid(0);
                isError = false;

                //INSERT new Log Entry
                sqlCommandLogInsert.Parameters["@ItemId"].Value = itemId;
                logid = Int32.Parse(sqlCommandLogInsert.ExecuteScalar().ToString());

                //Execute Cache Warming Event Level 1
                try
                {
                    response = await client.GetAsync(String.Concat(Settings.Default.ReportServerURL, "powerbi/?id=", itemId.ToString()));
                    response.EnsureSuccessStatusCode();
                }
                catch (HttpRequestException e)
                {
                    //UPDATE Log Set to Error
                    sqlCommandLogUpdate.Parameters["@Status"].Value = 9;
                    sqlCommandLogUpdate.Parameters["@Details"].Value = e.Message;
                    sqlCommandLogUpdate.Parameters["@CacheWarmingLogID"].Value = logid;
                    sqlCommandLogUpdate.ExecuteNonQuery();
                    isError = true;
                }


                if (!isError)
                {
                    //Execute Cache Warming Event Level 2
                    try
                    {

                        response = await client.GetAsync(String.Concat(Settings.Default.ReportServerURL, "powerbi/api/explore/reports/", itemId.ToString(), "/modelsAndExploration?preferReadOnlySession=true"));
                        response.EnsureSuccessStatusCode();
                    }
                    catch (HttpRequestException e)
                    {
                        //UPDATE Log Set to Error
                        sqlCommandLogUpdate.Parameters["@Status"].Value = 19;
                        sqlCommandLogUpdate.Parameters["@Details"].Value = e.Message;
                        sqlCommandLogUpdate.Parameters["@CacheWarmingLogID"].Value = logid;
                        sqlCommandLogUpdate.ExecuteNonQuery();
                        isError = true;
                    }

                    // UPDATE Log Successful
                    sqlCommandLogUpdate.Parameters["@Status"].Value = 1;
                    sqlCommandLogUpdate.Parameters["@Details"].Value = DBNull.Value;
                    sqlCommandLogUpdate.Parameters["@CacheWarmingLogID"].Value = logid;
                    sqlCommandLogUpdate.ExecuteNonQuery();
                }
            }
            sqlReaderReportList.Close();
            sqlconLog.Close();
            sqlcon.Close();
        }

        public void CopyExecutionLog()
        {
            SqlConnection sqlcon = new SqlConnection(Settings.Default.SQLConnectionString);
            SqlCommand sqlCommand = new SqlCommand(@"MERGE ReportServerTools.dbo.ExecutionLogStorage as tgt
    USING
	(SELECT [LogEntryId]
		  ,[InstanceName]
		  ,[ReportID]
		  ,[UserName]
		  ,[ExecutionId]
		  ,[RequestType]
		  ,[Format]
		  ,[Parameters]
		  ,[ReportAction]
		  ,[TimeStart]
		  ,[TimeEnd]
		  ,[TimeDataRetrieval]
		  ,[TimeProcessing]
		  ,[TimeRendering]
		  ,[Source]
		  ,[Status]
		  ,[ByteCount]
		  ,[RowCount]
		  ,[AdditionalInfo]
	  FROM [ReportServer].[dbo].[ExecutionLogStorage]) As src
	  ([LogEntryId],[InstanceName],[ReportID],[UserName],[ExecutionId],[RequestType],[Format],[Parameters],[ReportAction],[TimeStart],[TimeEnd],[TimeDataRetrieval],[TimeProcessing],[TimeRendering],[Source],[Status],[ByteCount],[RowCount],[AdditionalInfo])
ON (tgt.[LogEntryId] = src.[LogEntryId])
WHEN NOT MATCHED BY TARGET THEN
	INSERT ([LogEntryId],[InstanceName],[ReportID],[UserName],[ExecutionId],[RequestType],[Format],[Parameters],[ReportAction],[TimeStart],[TimeEnd],[TimeDataRetrieval],[TimeProcessing],[TimeRendering],[Source],[Status],[ByteCount],[RowCount],[AdditionalInfo])
	VALUES (src.[LogEntryId],src.[InstanceName],src.[ReportID],src.[UserName],src.[ExecutionId],src.[RequestType],src.[Format],src.[Parameters],src.[ReportAction],src.[TimeStart],src.[TimeEnd],src.[TimeDataRetrieval],src.[TimeProcessing],src.[TimeRendering],src.[Source],src.[Status],src.[ByteCount],[RowCount],src.[AdditionalInfo]);", sqlcon);
            sqlcon.Open();
            sqlCommand.ExecuteNonQuery();
            sqlcon.Close();
        }

        public void CopySubscriptionLog()
        {
            // TODO Add Connection and SQL Code to copy / Merge Log entries
            
        }
    }
}
